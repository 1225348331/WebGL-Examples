#version 300 es
precision mediump float;

out vec4 outColor;

void main() {
  outColor = vec4(1.0f, 0, 0, 1);
}