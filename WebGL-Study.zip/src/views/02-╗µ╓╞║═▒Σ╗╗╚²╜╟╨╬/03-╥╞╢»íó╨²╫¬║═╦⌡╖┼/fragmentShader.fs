#version 300 es
precision highp float;

out vec4 outColor;
void main() {
  outColor = vec4(0.8275, 0.4157, 0.0784, 1.0);
}