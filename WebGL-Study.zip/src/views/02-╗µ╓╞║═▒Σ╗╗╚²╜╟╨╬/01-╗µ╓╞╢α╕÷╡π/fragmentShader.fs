#version 300 es
precision highp float;

out vec4 outColor;

void main() {
  outColor = vec4(1, 0, 1, 1);
}