<script lang="ts" setup></script>
<template>
  <router-view></router-view>
</template>
<style lang="scss" scoped></style>
