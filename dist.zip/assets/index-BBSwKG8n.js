import{i as _,c as p,s as M,a as v,d as g}from"./webgl-BK-JQzqJ.js";import{P as B}from"./tweakpane-DhSwS92u.js";import{d as b,o as y,b as P,P as w,K as C}from"./index-BtaXy4Tv.js";import{c as s,l as u,p as x,t as h,r as F,s as I}from"./mat4-BT8WumiK.js";import{f as V}from"./vec3-CN1kTKF3.js";var A=`#version 300 es

in vec4 a_Position;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Color = a_Color;\r
}`,j=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`;const L=b({__name:"index",setup(z){const r=e=>V(e.x,e.y,e.z),t=new B;let a={x:0,y:0,theta:0,scaleX:1,scaleY:1,eye:{x:0,y:0,z:0},target:{x:0,y:0,z:-1},upDirection:{x:0,y:1,z:0},near:1,far:6,fov:45,aspect:1};const o=t.addFolder({title:"模型矩阵"});o.addBinding(a,"x",{min:-1,max:1,label:"x轴平移"}),o.addBinding(a,"y",{min:-1,max:1,label:"y轴平移"}),o.addBinding(a,"theta",{min:-180,max:180,label:"旋转角度"}),o.addBinding(a,"scaleX",{min:.5,max:2,label:"X轴缩放"}),o.addBinding(a,"scaleY",{min:.5,max:2,label:"Y轴缩放"});const m=t.addFolder({title:"视图矩阵"});m.addBinding(a,"eye",{min:-1,max:1,label:"视点"}),m.addBinding(a,"target",{min:-1,max:1,label:"目标点"}),m.addBinding(a,"upDirection",{min:-1,max:1,label:"上方向"});const d=t.addFolder({title:"透视矩阵"});d.addBinding(a,"near",{view:"slider",min:0,max:3,label:"近裁剪面"}),d.addBinding(a,"far",{view:"slider",min:3,max:6,label:"远裁剪面"}),d.addBinding(a,"fov",{view:"slider",min:0,max:180,label:"夹角"}),d.addBinding(a,"aspect",{min:1,max:1,label:"宽高比"});let f={a_Position:{data:[-.5,0,-4,.5,-.5,-4,.5,.5,-4,.5,.4,-2,-.5,.4,-2,0,-.6,-2]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0]}},n={u_ModelMatrix:s(),u_ViewMatrix:u(s(),r(a.eye),r(a.target),r(a.upDirection)),u_ProjMatrix:x(s(),a.fov*Math.PI/180,a.aspect,a.near,a.far)};const c=(e,i)=>{const l=p(e,f);M(e,i,l),v(i,n),g(e,l,e.TRIANGLES)};return y(()=>{const{gl:e,programInfo:i,clearGL:l}=_(A,j);c(e,i),t.on("change",()=>{l(),h(n.u_ModelMatrix,s(),[a.x,a.y,0]),F(n.u_ModelMatrix,n.u_ModelMatrix,a.theta*Math.PI/180),I(n.u_ModelMatrix,n.u_ModelMatrix,[a.scaleX,a.scaleY,1]),u(n.u_ViewMatrix,r(a.eye),r(a.target),r(a.upDirection)),x(n.u_ProjMatrix,a.fov*Math.PI/180,a.aspect,a.near,a.far),c(e,i)})}),P(()=>{t.dispose()}),(e,i)=>(C(),w("canvas"))}});export{L as default};
