import{g as s,f,p as l,s as u,a as c,d as m}from"./webgl-BK-JQzqJ.js";import{d as v,o as _,P as d,K as M}from"./index-BtaXy4Tv.js";import{s as x,c as i,l as p,p as g,t as h}from"./mat4-BT8WumiK.js";import{f as e}from"./vec3-CN1kTKF3.js";var P=`#version 300 es\r
precision mediump float;

in vec4 v_Normal;\r
out vec4 OutColor;

void main() {\r
  vec4 color = vec4(1.0f, 0.0f, 0.0f, 1.0f);\r
  vec4 lightColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);\r
  vec4 lightDirection = vec4(0.5f, 3.0f, 4.0f, 1.0f);\r
  vec4 diffuse = color * lightColor * max(dot(normalize(lightDirection), normalize(v_Normal)), 0.0f);\r
  OutColor = vec4(diffuse.rgb, 1.0f);\r
}`,C=`#version 300 es

in vec4 position;\r
in vec4 normal;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;

out vec4 v_Normal;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * position;\r
  v_Normal = transpose(inverse(u_ModelMatrix)) * normal;\r
}`,b=`#version 300 es\r
precision mediump float;

in vec4 v_Normal;\r
out vec4 OutColor;

void main() {\r
  vec4 color = vec4(1.0f, 1.0f, 0.0f, 1.0f);\r
  vec4 lightColor = vec4(0.0f, 1.0f, 0.0f, 1.0f);\r
  vec4 lightDirection = vec4(-0.5f, 3.0f, 4.0f, 1.0f);\r
  vec4 diffuse = color * lightColor * max(dot(normalize(lightDirection), normalize(v_Normal)), 0.0f);\r
  OutColor = vec4(diffuse.rgb, 1.0f);\r
}`,N=`#version 300 es

in vec4 position;\r
in vec4 normal;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;

out vec4 v_Normal;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * position;\r
  v_Normal = transpose(inverse(u_ModelMatrix)) * normal;\r
}`;const B=v({__name:"index",setup(I){let t={u_ModelMatrix:x(i(),i(),e(2,2,2)),u_ViewMatrix:p(i(),e(25,65,35),e(0,2,0),e(0,1,0)),u_ProjMatrix:g(i(),30*Math.PI/180,1,1,1e3)};const a=(r,o)=>{r.useProgram(o.program);const n=l.createCubeBufferInfo(r,3);u(r,o,n),c(o,t),m(r,n,r.TRIANGLES)};return _(()=>{const{gl:r}=s();r.enable(r.DEPTH_TEST);const o=f(r,[C,P]),n=f(r,[N,b]);a(r,o),h(t.u_ModelMatrix,t.u_ModelMatrix,e(4,0,0)),a(r,n)}),(r,o)=>(M(),d("canvas"))}});export{B as default};
