import{i as s,c as m,s as u,a as _,d as f}from"./webgl-BK-JQzqJ.js";import{d as l,o as c,P as v,K as d}from"./index-BtaXy4Tv.js";import{c as r,l as C,p}from"./mat4-BT8WumiK.js";import{f as a}from"./vec3-CN1kTKF3.js";var x=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`,M=`#version 300 es

uniform mat4 u_ModelMatrix; 
uniform mat4 u_ViewMatrix; 
uniform mat4 u_ProjMatrix; 
in vec4 a_Position; 
in vec4 a_Normal; 
in vec4 a_Color; 
uniform vec4 u_LightPosition; 
uniform vec4 u_LightColor; 
uniform vec4 u_AmbientColor; 

out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  
  vec4 diffuse = u_LightColor * a_Color * max(dot(normalize(a_Normal), normalize(u_LightPosition - a_Position)), 0.0f);\r
  
  vec4 ambient = u_AmbientColor * a_Color;\r
  
  v_Color = vec4(vec3(diffuse + ambient), a_Color.a);\r
}`;const L=l({__name:"index",setup(P){const i={a_Position:{numComponents:3,data:[2,2,2,-2,2,2,-2,-2,2,2,-2,2,2,2,2,2,-2,2,2,-2,-2,2,2,-2,2,2,2,2,2,-2,-2,2,-2,-2,2,2,-2,2,2,-2,2,-2,-2,-2,-2,-2,-2,2,-2,-2,-2,2,-2,-2,2,-2,2,-2,-2,2,2,-2,-2,-2,-2,-2,-2,2,-2,2,2,-2]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0]},a_Normal:{numComponents:3,data:[0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},t={u_ModelMatrix:r(),u_ViewMatrix:C(r(),a(6,6,14),a(0,0,0),a(0,1,0)),u_ProjMatrix:p(r(),40*Math.PI/180,1,2,100),u_LightColor:[1,1,1,1],u_LightPosition:[2.3,4,3.5,1],u_AmbientColor:[.2,.2,.2,1]};return c(()=>{const{gl:o,programInfo:n}=s(M,x),e=m(o,i);u(o,n,e),_(n,t),f(o,e,o.TRIANGLES)}),(o,n)=>(d(),v("canvas"))}});export{L as default};
