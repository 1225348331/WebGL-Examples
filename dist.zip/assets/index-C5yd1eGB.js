import{i as u,c as f,s as m,a as d,d as c}from"./webgl-BK-JQzqJ.js";import{P as _}from"./tweakpane-DhSwS92u.js";import{d as p,o as P,b as v,P as h,K as C}from"./index-BtaXy4Tv.js";import{c as l,r as M}from"./mat4-BT8WumiK.js";var x=`#version 300 es

in vec4 a_Position; 
in vec4 a_CenterPosition; 
uniform mat4 u_ModelMatrix; 

void main() {\r
  
  vec4 translatePosition = a_Position - a_CenterPosition;\r
  
  vec4 rotatedPosition = u_ModelMatrix * translatePosition;\r
  
  vec4 finalPosition = rotatedPosition + a_CenterPosition;

  gl_Position = finalPosition;\r
}`,I=`#version 300 es\r
precision highp float;

out vec4 outColor;\r
void main() {\r
  outColor = vec4(0.8275, 0.4157, 0.0784, 1.0);\r
}`;const L=p({__name:"index",setup(B){let e=new _,a={theta:0};return e.addBinding(a,"theta",{min:-360,max:360,step:1,label:"旋转角度"}),P(()=>{const{gl:n,programInfo:o}=u(x,I);let r={a_Position:{numComponents:2,data:[.2,0,.2,1,.8,0]},a_CenterPosition:{numComponents:2,data:[.2,0,.2,0,.2,0]}},t={u_ModelMatrix:l()};const i=f(n,r);m(n,o,i),d(o,t),c(n,i,n.TRIANGLES),e.on("change",()=>{M(t.u_ModelMatrix,l(),a.theta*Math.PI/180);const s=f(n,r);m(n,o,s),d(o,t),n.clear(n.COLOR_BUFFER_BIT),c(n,s,n.TRIANGLES)})}),v(()=>{e.dispose()}),(n,o)=>(C(),h("canvas"))}});export{L as default};
