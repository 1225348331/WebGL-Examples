import{i as s,c as u,s as m,a as f,d as _}from"./webgl-BK-JQzqJ.js";import{d as c,o as l,P as d,K as p}from"./index-BtaXy4Tv.js";import{c as n,l as v,p as M}from"./mat4-BT8WumiK.js";import{f as a}from"./vec3-CN1kTKF3.js";var x=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`,C=`#version 300 es

uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
in vec4 a_Position;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Color = a_Color;\r
}`;const h=c({__name:"index",setup(P){const t={a_Position:{numComponents:3,data:[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,-1,1,-1,-1,1,1,-1,1,1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1]},a_Color:{numComponents:3,data:[.4,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,1,.4,1,1,.4,1,1,.4,1,1,.4,1,1,1,1,1,1,1,1,1,1,1,1,.4,1,1,.4,1,1,.4,1,1,.4,1,1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},i={u_ModelMatrix:n(),u_ViewMatrix:v(n(),a(3,3,7),a(0,0,0),a(0,1,0)),u_ProjMatrix:M(n(),60*Math.PI/180,1,2,30)};return l(()=>{const{gl:o,programInfo:r}=s(C,x),e=u(o,t);m(o,r,e),f(r,i),_(o,e,o.TRIANGLES)}),(o,r)=>(p(),d("canvas"))}});export{h as default};
