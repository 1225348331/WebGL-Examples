import{i as s,c as m,s as u,a as _,d as l}from"./webgl-BK-JQzqJ.js";import{d as c,o as f,P as v,K as d}from"./index-BtaXy4Tv.js";import{c as n,l as p,p as C}from"./mat4-BT8WumiK.js";import{f as a}from"./vec3-CN1kTKF3.js";var x=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`,M=`#version 300 es

uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
in vec4 a_Position; 
in vec4 a_Color; 
in vec4 a_Normal; 
uniform vec4 u_LightColor; 
uniform vec4 u_LightDirection; 

out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Color = u_LightColor * a_Color * max(dot(normalize(u_LightDirection), normalize(a_Normal)), 0.0f);\r
  v_Color = vec4(vec3(v_Color), a_Color.a);\r
}`;const A=c({__name:"index",setup(g){const t={a_Position:{numComponents:3,data:[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,-1,1,-1,-1,1,1,-1,1,1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0]},a_Normal:{numComponents:3,data:[0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},i={u_ModelMatrix:n(),u_ViewMatrix:p(n(),a(3,3,7),a(0,0,0),a(0,1,0)),u_ProjMatrix:C(n(),60*Math.PI/180,1,2,30),u_LightColor:[1,1,1,1],u_LightDirection:[.5,3,4,1]};return f(()=>{const{gl:o,programInfo:r}=s(M,x),e=m(o,t);u(o,r,e),_(r,i),l(o,e,o.TRIANGLES)}),(o,r)=>(d(),v("canvas"))}});export{A as default};
