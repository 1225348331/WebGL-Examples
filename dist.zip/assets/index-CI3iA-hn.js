import{i as c,c as f,s as u,a as i,d as l}from"./webgl-BK-JQzqJ.js";import{P as p}from"./tweakpane-DhSwS92u.js";import{d as _,o as x,b as B,P as g,K as v}from"./index-BtaXy4Tv.js";import{c as d,t as M,r as h,s as b}from"./mat4-BT8WumiK.js";var I=`#version 300 es

in vec4 a_Position;\r
uniform mat4 u_ModelMatrix;

void main() {\r
  gl_Position = u_ModelMatrix * a_Position;\r
}`,P=`#version 300 es\r
precision highp float;

out vec4 outColor;\r
void main() {\r
  outColor = vec4(0.8275, 0.4157, 0.0784, 1.0);\r
}`;const R=_({__name:"index",setup(y){let n=new p,a={x:0,y:0,theta:0,scaleX:1,scaleY:1};return n.addBinding(a,"x",{min:-.5,max:.5,step:.01,label:"x轴平移"}),n.addBinding(a,"y",{min:-.5,max:.5,step:.01,label:"y轴平移"}),n.addBinding(a,"theta",{min:-180,max:180,step:1,label:"旋转角度"}),n.addBinding(a,"scaleX",{min:.5,max:2,step:.1,label:"X轴缩放"}),n.addBinding(a,"scaleY",{min:.5,max:2,step:.1,label:"Y轴缩放"}),x(()=>{const{gl:e,programInfo:o}=c(I,P);let m={a_Position:{numComponents:2,data:[.5,-.8,.5,.5,.2,.5]}},r={u_ModelMatrix:d()};const s=f(e,m);u(e,o,s),i(o,r),l(e,s,e.TRIANGLES),n.on("change",()=>{const t=d();M(t,t,[a.x,a.y,0]),h(t,t,a.theta*Math.PI/180),b(t,t,[a.scaleX,a.scaleY,1]),r.u_ModelMatrix=t,i(o,r),e.clear(e.COLOR_BUFFER_BIT),l(e,s,e.TRIANGLES)})}),B(()=>{n.dispose()}),(e,o)=>(v(),g("canvas"))}});export{R as default};
