import{i as p,b as v,c as C,s as M,a as T,d as P}from"./webgl-BK-JQzqJ.js";import{i as B}from"./landScape-WBMzbjzh.js";import{d as w,o as A,P as b,K as g}from"./index-BtaXy4Tv.js";import{c as s,l as I,p as h}from"./mat4-BT8WumiK.js";import{f as u}from"./vec3-CN1kTKF3.js";var y=`#version 300 es

in vec4 a_Position;\r
in vec2 a_TexCoord;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
out vec2 v_TexCoord;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_TexCoord = a_TexCoord;\r
}`,G=`#version 300 es\r
precision mediump float;

in vec2 v_TexCoord;\r
uniform sampler2D u_Texture;\r
out vec4 outColor;

void main() {\r
  outColor = texture(u_Texture, v_TexCoord);\r
}`;const N=w({__name:"index",setup(E){let _={a_Position:{numComponents:3,data:[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,-1,1,-1,-1,1,1,-1,1,1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1]},a_TexCoord:{numComponents:2,data:[1,1,0,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,1,0,0,0,1,0,1,1,0,1,0,0,1,0,1,1,0,1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},m={u_ModelMatrix:s(),u_ViewMatrix:I(s(),u(3,3,7),u(0,0,0),u(0,1,0)),u_ProjMatrix:h(s(),50*Math.PI/180,1,2,100),u_Texture:null};const f=(e,r)=>{const n=C(e,_);M(e,r,n),T(r,m),P(e,n,e.TRIANGLES)};return A(()=>{const{gl:e,programInfo:r,canvas:n,clearGL:d}=p(y,G);v(e,{src:B,flipY:1},(a,t,i)=>{m.u_Texture=t,f(e,r)}),n.onmousedown=a=>{d(),f(e,r);let t=a.clientX,i=a.clientY,o=a.target.getBoundingClientRect();if(o.left<=t&&t<o.right&&o.top<=i&&i<o.bottom){let c=t-o.left,x=o.bottom-i,l=new Uint8Array(4);e.readPixels(c,x,1,1,e.RGBA,e.UNSIGNED_BYTE,l),l[0]&&alert("物体被选中了")}}}),(e,r)=>(g(),b("canvas"))}});export{N as default};
