import{i as u,e as i,c as m,s as c,a as f,d as _}from"./webgl-BK-JQzqJ.js";import{i as d}from"./square-TeOgNROa.js";import{d as x,o as l,P as v,K as p}from"./index-BtaXy4Tv.js";var T=`#version 300 es\r
precision mediump float;

in vec2 v_TexCoord;\r
uniform sampler2D u_Texture1;\r
uniform sampler2D u_Texture2;\r
out vec4 outColor;

void main() {\r
  vec4 color1 = texture(u_Texture1, v_TexCoord);\r
  vec4 color2 = texture(u_Texture2, v_TexCoord);\r
  outColor = mix(color1, color2, 0.5f);\r
}`,C=`#version 300 es 

in vec4 a_Position;\r
in vec2 a_TexCoord;\r
out vec2 v_TexCoord;

void main() {\r
  gl_Position = a_Position;\r
  v_TexCoord = a_TexCoord;\r
}`;const g="/assets/square1-CM-WaDSU.png",D=x({__name:"index",setup(A){return l(()=>{const{gl:e,programInfo:r,clearGL:t}=u(C,T);let a={a_Position:{numComponents:2,data:[-.5,.5,-.5,-.5,.5,-.5,.5,.5]},a_TexCoord:{numComponents:2,data:[0,1,0,0,1,0,1,1]}};i(e,{texture1:{src:d,flipY:1},texture2:{src:g,flipY:1}},(B,o,I)=>{let s={u_Texture1:o.texture1,u_Texture2:o.texture2};t();const n=m(e,a);c(e,r,n),f(r,s),_(e,n,e.TRIANGLE_FAN)})}),(e,r)=>(p(),v("canvas"))}});export{D as default};
