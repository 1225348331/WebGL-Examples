import{i as C,p as x,b as T,h as B,s as d,a as M,d as p}from"./webgl-BK-JQzqJ.js";import{i as h}from"./square-TeOgNROa.js";import{d as P,o as A,P as w,K as R}from"./index-BtaXy4Tv.js";import{s as G,c as r,l as v,p as F,t as L,a as I}from"./mat4-BT8WumiK.js";import{f as t}from"./vec3-CN1kTKF3.js";var N=`#version 300 es\r
precision mediump float;

in vec2 v_TexCoord;\r
uniform sampler2D u_Texture;

out vec4 outColor;

void main() {\r
  outColor = texture(u_Texture, v_TexCoord);\r
}`,O=`#version 300 es 

uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
in vec4 position;\r
in vec2 texcoord;\r
out vec2 v_TexCoord;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * position;\r
  v_TexCoord = texcoord;\r
}`;const H=P({__name:"index",setup(S){var u=256,f=256;const E=e=>{const o=[{format:e.RGBA,type:e.UNSIGNED_BYTE,min:e.LINEAR,wrap:e.CLAMP_TO_EDGE}];return B(e,o,u,f)};let a={u_ModelMatrix:G(r(),r(),t(1,1,1)),u_ViewMatrix:v(r(),t(0,2,-2),t(0,0,0),t(0,1,0)),u_ProjMatrix:F(r(),40*Math.PI/180,1,1,1e3),u_Texture:null},n={u_ModelMatrix:L(r(),r(),t(0,1,-.5)),u_ViewMatrix:v(r(),t(2.5,6.5,3.5),t(0,2,0),t(0,1,0)),u_ProjMatrix:F(r(),40*Math.PI/180,1,1,1e3),u_Texture:null};return A(()=>{const{gl:e,programInfo:o,clearGL:i,canvas:s}=C(O,N);let m=x.createCubeBufferInfo(e,2),_=x.createPlaneBufferInfo(e),b=T(e,{src:h,flipY:1});n.u_Texture=b;const l=E(e);e.enable(e.CULL_FACE);const c=()=>{e.bindFramebuffer(e.FRAMEBUFFER,l.framebuffer),e.viewport(0,0,u,f),e.clearColor(.2,.2,.4,1),i(),d(e,o,m),I(n.u_ModelMatrix,n.u_ModelMatrix,Math.PI/1800),M(o,n),p(e,m),e.bindFramebuffer(e.FRAMEBUFFER,null),e.viewport(0,0,s.width,s.height),e.clearColor(0,0,0,0),i(),d(e,o,_),a.u_Texture=l.attachments[0],I(a.u_ModelMatrix,a.u_ModelMatrix,Math.PI/1800),M(o,a),p(e,_),requestAnimationFrame(c)};c()}),(e,o)=>(R(),w("canvas"))}});export{H as default};
