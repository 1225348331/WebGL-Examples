import{i as d,c as u,s as f,a as l,d as _}from"./webgl-BK-JQzqJ.js";import{P as p}from"./tweakpane-DhSwS92u.js";import{d as v,o as x,b as C,P as y,K as g}from"./index-BtaXy4Tv.js";import{l as m,c as B}from"./mat4-BT8WumiK.js";import{f as b}from"./vec3-CN1kTKF3.js";var w=`#version 300 es

in vec4 a_Position;\r
uniform mat4 u_ViewMatrix;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ViewMatrix * a_Position;\r
  v_Color = a_Color;\r
}`,P=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`;const I=v({__name:"index",setup(V){const o=e=>b(e.x,e.y,e.z),a=new p;let n={eye:{x:.25,y:.25,z:.25},target:{x:0,y:0,z:0},upDirection:{x:0,y:1,z:0}};a.addBinding(n,"eye",{min:-1,max:1,label:"视点"}),a.addBinding(n,"target",{min:-1,max:1,label:"目标点"}),a.addBinding(n,"upDirection",{min:-1,max:1,label:"上方向"});let c={a_Position:{data:[-.5,0,-.4,.5,-.5,-.4,.5,.5,-.4,.5,.4,-.2,-.5,.4,-.2,0,-.6,-.2,0,.5,0,-.5,-.5,0,.5,-.5,0]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1]}},i={u_ViewMatrix:m(B(),o(n.eye),o(n.target),o(n.upDirection))};const s=(e,r)=>{const t=u(e,c);f(e,r,t),l(r,i),_(e,t,e.TRIANGLES)};return x(()=>{const{gl:e,programInfo:r,clearGL:t}=d(w,P);s(e,r),a.on("change",()=>{t(),m(i.u_ViewMatrix,o(n.eye),o(n.target),o(n.upDirection)),s(e,r)})}),C(()=>{a.dispose()}),(e,r)=>(g(),y("canvas"))}});export{I as default};
