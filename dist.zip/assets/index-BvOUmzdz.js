import{i as P,e as T,b as E,c as w,s as R,a as b,d as y}from"./webgl-BK-JQzqJ.js";import{g as B,b as o}from"./utils-DhsMP5cn.js";import{P as D}from"./tweakpane-DhSwS92u.js";import{d as g,o as L,b as F,P as U,K as N}from"./index-BtaXy4Tv.js";var k=`#version 300 es

in vec4 a_Position;\r
out vec2 v_Position;

void main() {\r
  gl_Position = a_Position;\r
  v_Position = (a_Position.xy + vec2(1.0f, 1.0f)) / 2.0f;\r
}`,O=`#version 300 es\r
precision mediump float;\r
precision mediump sampler2DArray;

in vec2 v_Position; 
uniform sampler2DArray u_TextureArray; 
uniform float u_CurrentIndex; 
uniform float u_Time; 
struct clampColor {\r
  float stop;\r
  vec4 color;\r
};\r
uniform clampColor clampColors[10];\r
out vec4 outColor;

void main() {\r
  float val1 = texture(u_TextureArray, vec3(v_Position, u_CurrentIndex)).r;\r
  float val2 = texture(u_TextureArray, vec3(v_Position, u_CurrentIndex + 1.0f)).r;\r
  float val = mix(val1, val2, u_Time);\r
  for(int i = 1; i < 10; i++) {\r
    if(val >= clampColors[i - 1].stop && val < clampColors[i].stop) {\r
      outColor = clampColors[i].color;\r
      break;\r
    }\r
  }

}`;const H=g({__name:"index",setup(G){let i=B();i.length=4;const p=new D({title:"绘制格点数据"});let r={currentIndex:0,time:0,speed:5};p.addBinding(r,"speed",{label:"动画速度",min:1,max:15});const _=e=>{const t=document.createElement("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");return n.drawImage(e,0,0),n.getImageData(0,0,e.width,e.height).data},x=(e,t)=>{let n={};return t.forEach((a,s)=>{n[`texture${s}`]={src:a,min:e.LINEAR,mag:e.LINEAR}}),new Promise(a=>{T(e,n,(s,c,u)=>{const l=u.texture0.width,m=u.texture0.height,d=t.length,f=new Uint8Array(l*m*d*4);Object.values(u).forEach((I,A)=>{const C=_(I);f.set(C,A*l*m*4)});let h=E(e,{target:e.TEXTURE_2D_ARRAY,width:l,height:m,depth:d,src:f,min:e.LINEAR,mag:e.LINEAR,wrap:e.CLAMP_TO_EDGE});a(h)})})},v=(e,t,n)=>{let a={a_Position:{numComponents:2,data:[-1,1,-1,-1,1,1,1,-1]}},s={u_TextureArray:n,u_Time:r.time,u_CurrentIndex:r.currentIndex,clampColors:[{stop:0,color:o(0)},{stop:.1,color:o(.1)},{stop:.2,color:o(.2)},{stop:.3,color:o(.3)},{stop:.4,color:o(.4)},{stop:.5,color:o(.5)},{stop:.6,color:o(.6)},{stop:.7,color:o(.7)},{stop:.8,color:o(.8)},{stop:1,color:o(1)}]};const c=w(e,a);R(e,t,c),b(t,s),e.clear(e.COLOR_BUFFER_BIT|e.DEPTH_BUFFER_BIT),y(e,c,e.TRIANGLE_STRIP)};return L(()=>{const{gl:e,programInfo:t}=P(k,O);x(e,i).then(n=>{const a=()=>{r.time+=r.speed/8e3,r.time>=1&&(r.currentIndex=i.length-2?r.currentIndex=0:++r.currentIndex,r.time=0),v(e,t,n),requestAnimationFrame(a)};a()})}),F(()=>{p.dispose()}),(e,t)=>(N(),U("canvas"))}});export{H as default};
