import{i,b as u,c as f,s as m,a as _,d}from"./webgl-BK-JQzqJ.js";import{i as c}from"./square-TeOgNROa.js";import{d as v,o as l,P as p,K as x}from"./index-BtaXy4Tv.js";var C=`#version 300 es\r
precision mediump float;

in vec2 v_TexCoord;\r
uniform sampler2D u_Texture;

out vec4 outColor;

void main() {\r
  outColor = texture(u_Texture, v_TexCoord);\r
}`,T=`#version 300 es 

in vec4 a_Position;\r
in vec2 a_TexCoord;\r
out vec2 v_TexCoord;

void main() {\r
  gl_Position = a_Position;\r
  v_TexCoord = a_TexCoord;\r
}`;const b=v({__name:"index",setup(g){return l(()=>{const{gl:e,programInfo:o,clearGL:n}=i(T,C);let a={a_Position:{numComponents:2,data:[-.5,.5,-.5,-.5,.5,-.5,.5,.5]},a_TexCoord:{numComponents:2,data:[0,1,0,0,1,0,1,1]}};u(e,{src:c,flipY:1},(A,t)=>{let s={u_Texture:t};n();const r=f(e,a);m(e,o,r),_(o,s),d(e,r,e.TRIANGLE_FAN)})}),(e,o)=>(x(),p("canvas"))}});export{b as default};
