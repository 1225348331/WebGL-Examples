import{i as h,c as p,s as v,a as B,d as C}from"./webgl-BK-JQzqJ.js";import{d as P,o as b,P as g,K as E}from"./index-BtaXy4Tv.js";var I=`#version 300 es

in vec4 a_Position;

void main() {\r
  gl_Position = a_Position;\r
  gl_PointSize = 20.0f;\r
}`,x=`#version 300 es\r
precision mediump float;

out vec4 outColor;\r
uniform vec2 u_Color;

void main() {\r
  outColor = vec4(u_Color, 1.0f, 1.0f);\r
}`;const w=P({__name:"index",setup(F){let i=[],c=[];const l=(e,o,a,r)=>{const n=p(e,a);v(e,o,n),B(o,r),C(e,n,e.POINTS)};return b(()=>{var a;const{gl:e,programInfo:o}=h(I,x);(a=document.querySelector("canvas"))==null||a.addEventListener("click",r=>{var f;let n=r.clientX,s=r.clientY;const t=(f=r.target)==null?void 0:f.getBoundingClientRect();n=(n-t.left-t.width/2)/(t.width/2),s=(t.height/2-(s-t.top))/(t.height/2),i.push([n,s]),c.push([Math.abs(n),Math.abs(s)]),e.clear(e.COLOR_BUFFER_BIT|e.DEPTH_BUFFER_BIT),i.forEach((u,d)=>{let _={a_Position:{numComponents:2,data:[u[0],u[1]]}},m={u_Color:c[d]};l(e,o,_,m)})})}),(e,o)=>(E(),g("canvas"))}});export{w as default};
