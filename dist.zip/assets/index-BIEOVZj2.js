import{i as u,c as _,s as p,a as v,d as m}from"./webgl-BK-JQzqJ.js";import{P as x}from"./tweakpane-DhSwS92u.js";import{d as P,o as b,b as B,P as g,K as y}from"./index-BtaXy4Tv.js";import{l as d,c as f,p as c}from"./mat4-BT8WumiK.js";import{f as C}from"./vec3-CN1kTKF3.js";var M=`#version 300 es

in vec4 a_Position;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * a_Position;\r
  v_Color = a_Color;\r
}`,w=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`;const S=P({__name:"index",setup(I){const r=a=>C(a.x,a.y,a.z),n=new x;let e={eye:{x:0,y:0,z:0},target:{x:0,y:0,z:-1},upDirection:{x:0,y:1,z:0},near:1,far:6,fov:90,aspect:1};n.addBinding(e,"eye",{min:-1,max:1,label:"视点"}),n.addBinding(e,"target",{min:-1,max:1,label:"目标点"}),n.addBinding(e,"upDirection",{min:-1,max:1,label:"上方向"}),n.addBinding(e,"near",{view:"slider",min:0,max:3,label:"近裁剪面"}),n.addBinding(e,"far",{view:"slider",min:3,max:6,label:"远裁剪面"}),n.addBinding(e,"fov",{view:"slider",min:0,max:180,label:"夹角"}),n.addBinding(e,"aspect",{min:1,max:1,label:"宽高比"});let l={a_Position:{data:[0,2.5,-5,-2.5,-2.5,-5,2.5,-2.5,-5,0,3,-5,-3,-3,-5,3,-3,-5]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0]}},t={u_ViewMatrix:d(f(),r(e.eye),r(e.target),r(e.upDirection)),u_ProjMatrix:c(f(),e.fov*Math.PI/180,e.aspect,e.near,e.far)};const s=(a,o)=>{const i=_(a,l);p(a,o,i),v(o,t),m(a,i,a.TRIANGLES,3,0),a.polygonOffset(2,2),m(a,i,a.TRIANGLES,3,3)};return b(()=>{const{gl:a,programInfo:o,clearGL:i}=u(M,w);a.enable(a.POLYGON_OFFSET_FILL),s(a,o),n.on("change",()=>{i(),d(t.u_ViewMatrix,r(e.eye),r(e.target),r(e.upDirection)),c(t.u_ProjMatrix,e.fov*Math.PI/180,e.aspect,e.near,e.far),s(a,o)})}),B(()=>{n.dispose()}),(a,o)=>(y(),g("canvas"))}});export{S as default};
