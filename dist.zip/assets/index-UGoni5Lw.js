import{i as f,c as u,s as c,a as l,d as m}from"./webgl-BK-JQzqJ.js";import{d as _,o as d,P,K as p}from"./index-BtaXy4Tv.js";import{c as v,r as M}from"./mat4-BT8WumiK.js";var C=`#version 300 es

in vec4 a_Position;\r
in vec4 a_CenterPosition;\r
uniform mat4 u_ModelMatrix;

void main() {\r
  
  vec4 translatePosition = a_Position - a_CenterPosition;\r
  
  vec4 rotatedPosition = u_ModelMatrix * translatePosition;\r
  
  vec4 finalPosition = rotatedPosition + a_CenterPosition;

  gl_Position = finalPosition;\r
}`,x=`#version 300 es\r
precision mediump float;

out vec4 outColor;

void main() {\r
  outColor = vec4(1.0f, 0, 0, 1);\r
}`;const g=_({__name:"index",setup(B){let e=[],r=[];for(let n=-1;n<=1-.2;n+=.2)for(let o=-1;o<=1-.3;o+=.3)e.push(n,o,n+.1,o,n+.2,o+.3),r.push(n+.1,o+.1,n+.1,o+.1,n+.1,o+.1);let s={a_Position:{numComponents:2,data:e},a_CenterPosition:{numComponents:2,data:r}},t={u_ModelMatrix:v()};return d(()=>{const{gl:n,programInfo:o}=f(C,x),a=u(n,s);c(n,o,a);const i=()=>{M(t.u_ModelMatrix,t.u_ModelMatrix,Math.PI/360),n.clear(n.COLOR_BUFFER_BIT),l(o,t),m(n,a,n.TRIANGLES),requestAnimationFrame(i)};i()}),(n,o)=>(p(),P("canvas"))}});export{g as default};
