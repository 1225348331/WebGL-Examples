var R=Object.defineProperty;var S=(i,e,t)=>e in i?R(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var n=(i,e,t)=>S(i,typeof e!="symbol"?e+"":e,t);import{f as d,c as x,b as c,s as l,a as _,d as p,g as E}from"./webgl-BK-JQzqJ.js";import{d as P,o as b,P as A,K as D}from"./index-BtaXy4Tv.js";var M=`#version 300 es

in float a_index;\r
uniform sampler2D u_particles;\r
uniform float u_particles_res;

out vec2 v_particle_pos;

void main() {\r
  vec4 color = texture(u_particles, vec2(fract(a_index / u_particles_res), floor(a_index / u_particles_res) / u_particles_res));\r
  v_particle_pos = vec2(color.r / 255.0f + color.b, color.g / 255.0f + color.a);\r
  gl_Position = vec4(2.0f * v_particle_pos.x - 1.0f, 1.0f - 2.0f * v_particle_pos.y, 0, 1);\r
  gl_PointSize = 1.0f;\r
}`,y=`#version 300 es\r
precision mediump float;

uniform sampler2D u_wind;\r
uniform vec2 u_wind_min;\r
uniform vec2 u_wind_max;\r
uniform sampler2D u_color_ramp;\r
in vec2 v_particle_pos;

out vec4 outColor;

void main() {\r
  
  vec2 velocity = mix(u_wind_min, u_wind_max, texture(u_wind, v_particle_pos).rg);\r
  float speed_t = length(velocity) / length(u_wind_max);\r
  
  vec2 ramp_pos = vec2(fract(16.0f * speed_t), floor(16.0f * speed_t) / 16.0f);\r
  outColor = texture(u_color_ramp, ramp_pos);\r
}`,g=`#version 300 es

in vec2 a_pos;\r
out vec2 v_tex_pos;

void main() {\r
  gl_Position = vec4(1.0f - 2.0f * a_pos, 0, 1);\r
  v_tex_pos = a_pos;\r
}`,B=`#version 300 es\r
precision mediump float;

uniform sampler2D u_screen;\r
uniform float u_opacity;

in vec2 v_tex_pos;\r
out vec4 outColor;

void main() {\r
  vec4 color = texture(u_screen, 1.0f - v_tex_pos);\r
  
  
  outColor = vec4(floor(255.0f * color * u_opacity) / 255.0f);\r
}`,I=`#version 300 es\r
precision mediump float;

uniform sampler2D u_particles;\r
uniform sampler2D u_wind;\r
uniform vec2 u_wind_res;\r
uniform vec2 u_wind_min;\r
uniform vec2 u_wind_max;\r
uniform float u_rand_seed;\r
uniform float u_speed_factor;\r
uniform float u_drop_rate;\r
uniform float u_drop_rate_bump;

in vec2 v_tex_pos;\r
out vec4 outColor;

const vec3 rand_constants = vec3(12.9898f, 78.233f, 4375.85453f);\r
float rand(const vec2 co) {\r
  float t = dot(rand_constants.xy, co);\r
  return fract(sin(t) * (rand_constants.z + t));\r
}

vec2 lookup_wind(const vec2 uv) {\r
  
  
  vec2 px = 1.0f / u_wind_res;\r
  vec2 vc = (floor(uv * u_wind_res)) * px;\r
  vec2 f = fract(uv * u_wind_res);\r
  vec2 tl = texture(u_wind, vc).rg;\r
  vec2 tr = texture(u_wind, vc + vec2(px.x, 0)).rg;\r
  vec2 bl = texture(u_wind, vc + vec2(0, px.y)).rg;\r
  vec2 br = texture(u_wind, vc + px).rg;\r
  return mix(mix(tl, tr, f.x), mix(bl, br, f.x), f.y);\r
}

void main() {\r
  vec4 color = texture(u_particles, v_tex_pos);\r
  
  vec2 pos = vec2(color.r / 255.0f + color.b, color.g / 255.0f + color.a);\r
  
  vec2 velocity = mix(u_wind_min, u_wind_max, lookup_wind(pos));\r
  float speed_t = length(velocity) / length(u_wind_max);

  
  float distortion = cos(radians(pos.y * 180.0f - 90.0f));\r
  vec2 offset = vec2(velocity.x / distortion, -velocity.y) * 0.0001f * u_speed_factor;

  
  pos = fract(1.0f + pos + offset);

  
  vec2 seed = (pos + v_tex_pos) * u_rand_seed;

  
  float drop_rate = u_drop_rate + speed_t * u_drop_rate_bump;\r
  float drop = step(1.0f - drop_rate, rand(seed));

  vec2 random_pos = vec2(rand(seed + 1.3f), rand(seed + 2.1f));\r
  pos = mix(pos, random_pos, drop);

  
  outColor = vec4(fract(pos * 255.0f), floor(pos * 255.0f) / 255.0f);\r
}`;const T="/assets/2016112000-BI27NGUl.png",C={0:"#3288bd",.1:"#66c2a5",.2:"#abdda4",.3:"#e6f598",.4:"#fee08b",.5:"#fdae61",.6:"#f46d43",1:"#d53e4f"};class N{constructor(e){n(this,"gl");n(this,"fadeOpacity");n(this,"speedFactor");n(this,"dropRate");n(this,"dropRateBump");n(this,"drawProgram");n(this,"screenProgram");n(this,"updateProgram");n(this,"quadBuffer");n(this,"framebuffer");n(this,"backgroundTexture");n(this,"screenTexture");n(this,"colorRampTexture");n(this,"particleStateResolution");n(this,"_numParticles");n(this,"particleStateTexture0");n(this,"particleStateTexture1");n(this,"particleIndexBuffer");n(this,"windData");n(this,"windTexture");this.gl=e,this.fadeOpacity=.996,this.speedFactor=.25,this.dropRate=.003,this.dropRateBump=.01,this.drawProgram=d(e,[M,y]),this.screenProgram=d(e,[g,B]),this.updateProgram=d(e,[g,I]),this.quadBuffer=x(e,{a_pos:{numComponents:2,data:[0,0,1,0,0,1,0,1,1,0,1,1]}}),this.framebuffer=e.createFramebuffer(),this.setColorRamp(C),this.resize()}resize(){const e=this.gl,t=new Uint8Array(e.canvas.width*e.canvas.height*4);this.backgroundTexture=c(e,{width:e.canvas.width,height:e.canvas.height,min:e.NEAREST,mag:e.NEAREST,src:t}),this.screenTexture=c(e,{width:e.canvas.width,height:e.canvas.height,min:e.NEAREST,mag:e.NEAREST,src:t})}setColorRamp(e){this.colorRampTexture=c(this.gl,{width:16,height:16,min:this.gl.LINEAR,mag:this.gl.LINEAR,src:F(e)})}set numParticles(e){const t=this.gl;this.particleStateResolution=Math.ceil(Math.sqrt(e));const r=this.particleStateResolution;this._numParticles=r*r;const a=new Uint8Array(this._numParticles*4);for(let o=0;o<a.length;o++)a[o]=Math.floor(Math.random()*256);this.particleStateTexture0=c(t,{min:t.NEAREST,mag:t.NEAREST,src:a,width:r,height:r}),this.particleStateTexture1=c(t,{min:t.NEAREST,mag:t.NEAREST,src:a,width:r,height:r});const s=new Float32Array(this._numParticles);for(let o=0;o<this._numParticles;o++)s[o]=o;this.particleIndexBuffer=x(t,{a_index:{numComponents:1,data:s}})}get numParticles(){return this._numParticles}setWind(e){this.windData=e,this.windTexture=c(this.gl,{min:this.gl.LINEAR,mag:this.gl.LINEAR,src:T})}draw(){const e=this.gl;e.disable(e.DEPTH_TEST),e.disable(e.STENCIL_TEST),this.drawScreen(),this.updateParticles()}drawScreen(){const e=this.gl;f(e,this.framebuffer,this.screenTexture),e.viewport(0,0,e.canvas.width,e.canvas.height),this.drawTexture(this.backgroundTexture,this.fadeOpacity),this.drawParticles(),f(e,null),e.enable(e.BLEND),e.blendFunc(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA),this.drawTexture(this.screenTexture,1),e.disable(e.BLEND);const t=this.backgroundTexture;this.backgroundTexture=this.screenTexture,this.screenTexture=t}drawTexture(e,t){const r=this.gl,a=this.screenProgram;r.useProgram(a.program);let s={u_screen:e,u_opacity:t};l(r,a,this.quadBuffer),_(a,s),p(r,this.quadBuffer,r.TRIANGLES)}drawParticles(){var a,s,o,u;const e=this.gl,t=this.drawProgram;e.useProgram(t.program);let r={u_particles:this.particleStateTexture0,u_particles_res:this.particleStateResolution,u_wind:this.windTexture,u_wind_min:[(a=this.windData)==null?void 0:a.uMin,(s=this.windData)==null?void 0:s.vMin],u_wind_max:[(o=this.windData)==null?void 0:o.uMax,(u=this.windData)==null?void 0:u.vMax],u_color_ramp:this.colorRampTexture};l(e,t,this.particleIndexBuffer),_(t,r),p(e,this.particleIndexBuffer,e.POINTS)}updateParticles(){var s,o,u,m,h,v;const e=this.gl;f(e,this.framebuffer,this.particleStateTexture1),e.viewport(0,0,this.particleStateResolution,this.particleStateResolution);const t=this.updateProgram;e.useProgram(t.program);let r={u_particles:this.particleStateTexture0,u_particles_res:this.particleStateResolution,u_wind:this.windTexture,u_wind_min:[(s=this.windData)==null?void 0:s.uMin,(o=this.windData)==null?void 0:o.vMin],u_wind_max:[(u=this.windData)==null?void 0:u.uMax,(m=this.windData)==null?void 0:m.vMax],u_color_ramp:this.colorRampTexture,u_rand_seed:Math.random(),u_wind_res:[(h=this.windData)==null?void 0:h.width,(v=this.windData)==null?void 0:v.height],u_speed_factor:this.speedFactor,u_drop_rate:this.dropRate,u_drop_rate_bump:this.dropRateBump};l(e,t,this.quadBuffer),_(t,r),p(e,this.quadBuffer,e.TRIANGLES);const a=this.particleStateTexture0;this.particleStateTexture0=this.particleStateTexture1,this.particleStateTexture1=a}}function F(i){const e=document.createElement("canvas"),t=e.getContext("2d");e.width=256,e.height=1;const r=t.createLinearGradient(0,0,256,0);for(const a in i)r.addColorStop(+a,i[a]);return t.fillStyle=r,t.fillRect(0,0,256,1),new Uint8Array(t.getImageData(0,0,256,1).data)}function f(i,e,t){i.bindFramebuffer(i.FRAMEBUFFER,e),t&&i.framebufferTexture2D(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,t,0)}const L="http://nomads.ncep.noaa.gov",U="2016-11-20T00:00Z",k=360,q=180,O=-21.32,z=26.8,G=-21.57,H=21.42,w={source:L,date:U,width:k,height:q,uMin:O,uMax:z,vMin:G,vMax:H},X=P({__name:"index",setup(i){return b(()=>{const{gl:e}=E(!0),t=new N(e);t.numParticles=65536,t.resize(),e.clearColor(0,0,0,1),e.clear(e.COLOR_BUFFER_BIT);const r=new Image;w.image=r,r.src=T,r.onload=function(){t.setWind(w)};function a(){t.windData&&t.draw(),requestAnimationFrame(a)}a()}),(e,t)=>(D(),A("canvas"))}});export{X as default};
