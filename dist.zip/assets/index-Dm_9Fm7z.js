import{i as v,b as p,c as C,s as T,a as P,d as g}from"./webgl-BK-JQzqJ.js";import{i as h}from"./landScape-WBMzbjzh.js";import{d as I,o as w,P as B,K as b}from"./index-BtaXy4Tv.js";import{c as _,l as A,p as Y,a as y,e as V}from"./mat4-BT8WumiK.js";import{f as d}from"./vec3-CN1kTKF3.js";var X=`#version 300 es

in vec4 a_Position;\r
in vec2 a_TexCoord;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
out vec2 v_TexCoord;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_TexCoord = a_TexCoord;\r
}`,j=`#version 300 es\r
precision mediump float;

in vec2 v_TexCoord;\r
uniform sampler2D u_Texture;\r
out vec4 outColor;

void main() {\r
  outColor = texture(u_Texture, v_TexCoord);\r
}`;const D=I({__name:"index",setup(k){let c={a_Position:{numComponents:3,data:[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,-1,1,-1,-1,1,1,-1,1,1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1]},a_TexCoord:{numComponents:2,data:[1,1,0,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,1,0,0,0,1,0,1,1,0,1,0,0,1,0,1,1,0,1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},i={u_ModelMatrix:_(),u_ViewMatrix:A(_(),d(3,3,7),d(0,0,0),d(0,1,0)),u_ProjMatrix:Y(_(),50*Math.PI/180,1,2,100),u_Texture:null},u=!1,l=-1,m=-1;const f=(e,s)=>{const t=C(e,c);T(e,s,t),P(s,i),g(e,t,e.TRIANGLES)};return w(()=>{const{gl:e,programInfo:s,canvas:t}=v(X,j);p(e,{src:h,flipY:1},(o,r,a)=>{i.u_Texture=r,f(e,s)}),t.onmousedown=o=>{let r=o.clientX,a=o.clientY,n=o.target.getBoundingClientRect();n.left<=r&&r<n.right&&n.top<=a&&a<n.bottom&&(l=r,m=a,u=!0)},t.onmouseup=()=>{u=!1},t.onmousemove=o=>{let r=o.clientX,a=o.clientY;if(u){var n=100/t.height,x=n*(r-l),M=n*(a-m);y(i.u_ModelMatrix,i.u_ModelMatrix,x*Math.PI/180),V(i.u_ModelMatrix,i.u_ModelMatrix,M*Math.PI/180),f(e,s)}l=r,m=a}}),(e,s)=>(b(),B("canvas"))}});export{D as default};
