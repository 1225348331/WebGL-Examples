import{i as f,c as m,s as l,a as c,d as p}from"./webgl-BK-JQzqJ.js";import{P as v}from"./tweakpane-DhSwS92u.js";import{d as h,o as P,b as x,P as g,K as w}from"./index-BtaXy4Tv.js";var C=`#version 300 es\r
precision highp float;

uniform float u_Resolution; 
uniform float u_Time; 
uniform float u_Speed; 
uniform vec4 u_Color; 
uniform float u_Width; 
in vec4 v_Position;

out vec4 outColor;

void main() {\r
  float coordX = u_Time * u_Speed / u_Resolution - 0.5f;\r
  if(v_Position.x >= coordX - u_Width / 2.0f && v_Position.x <= coordX + u_Width / 2.0f) {\r
    float opacity = smoothstep(-u_Width, u_Width, coordX - v_Position.x);\r
    
    outColor = vec4(u_Color.xyz, opacity);

  } else {\r
    outColor = vec4(0.0f, 0.0f, 0.0f, 0.0f);\r
  }\r
}`,W=`#version 300 es

in vec4 a_Position;\r
out vec4 v_Position;

void main() {\r
  gl_Position = a_Position;\r
  v_Position = a_Position;\r
}`;const A=h({__name:"index",setup(B){const i=new v({title:"平面扩散波"});let n={speed:20,width:.3};return i.addBinding(n,"speed",{label:"扩散速度",min:5,max:50}),i.addBinding(n,"width",{label:"波纹宽度",min:.1,max:1}),P(()=>{const{gl:e,programInfo:t,clearGL:u,width:r}=f(W,C);let d={a_Position:{numComponents:2,data:[-1,1,-1,-1,1,-1,1,1]}},o={u_Color:[0,1,0,1],u_Resolution:r,u_Time:0,u_Speed:n.speed,u_Width:n.width};const _=()=>{const s=m(e,d);l(e,t,s),c(t,o),p(e,s,e.TRIANGLE_FAN)},a=()=>{o.u_Time+=.1,o.u_Time*o.u_Speed>r&&(o.u_Time=0),u(),_(),requestAnimationFrame(a)};a(),i.on("change",()=>{o.u_Speed=n.speed,o.u_Width=n.width})}),x(()=>{i.dispose()}),(e,t)=>(w(),g("canvas"))}});export{A as default};
