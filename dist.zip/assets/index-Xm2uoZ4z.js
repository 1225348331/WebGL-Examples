import{i as r,c as a,s as t,d as s}from"./webgl-BK-JQzqJ.js";import{d as i,o as f,P as c,K as u}from"./index-BtaXy4Tv.js";var d=`#version 300 es

in vec4 a_Position;

void main() {\r
  gl_Position = a_Position;\r
}`,m=`#version 300 es\r
precision highp float;

out vec4 outColor;

void main() {\r
  outColor = vec4(1, 0, 1, 1);\r
}`;const g=i({__name:"index",setup(_){return f(()=>{const{gl:n,programInfo:o}=r(d,m),e=a(n,{a_Position:{numComponents:2,data:[-.2,.3,-.2,-.1,.2,.3,-.2,-.2,.2,-.2,.2,.1]}});t(n,o,e),s(n,e,n.TRIANGLES)}),(n,o)=>(u(),c("canvas"))}});export{g as default};
