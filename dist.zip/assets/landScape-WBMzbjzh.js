const s="/assets/landScape-6dqpsJ9B.png";export{s as i};
