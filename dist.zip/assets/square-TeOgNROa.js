const s="/assets/square-CFUDHTR-.png";export{s as i};
