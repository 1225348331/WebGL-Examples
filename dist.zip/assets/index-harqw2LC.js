import{i as f,c as u,s as c,a as _,d as p}from"./webgl-BK-JQzqJ.js";import{P as v}from"./tweakpane-DhSwS92u.js";import{d as x,o as b,b as g,P as w,K as B}from"./index-BtaXy4Tv.js";import{l as C,c as m,o as d}from"./mat4-BT8WumiK.js";import{f as P}from"./vec3-CN1kTKF3.js";var h=`#version 300 es

in vec4 a_Position;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * a_Position;\r
  v_Color = a_Color;\r
}`,y=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`;const k=x({__name:"index",setup(M){const t=o=>P(o.x,o.y,o.z),e=new v;let r={eye:{x:0,y:0,z:0},target:{x:0,y:0,z:-1},upDirection:{x:0,y:1,z:0},near:.1,far:.5,left:-1,right:1,bottom:-1,top:1};e.addBinding(r,"near",{view:"slider",min:.1,max:.3,label:"近裁剪面"}),e.addBinding(r,"far",{view:"slider",min:.3,max:.5,label:"远裁剪面"}),e.addBinding(r,"left",{view:"slider",min:-1,max:0,label:"左边界"}),e.addBinding(r,"right",{view:"slider",min:0,max:1,label:"右边界"}),e.addBinding(r,"top",{view:"slider",min:0,max:1,label:"上边界"}),e.addBinding(r,"bottom",{view:"slider",min:-1,max:0,label:"下边界"});let l={a_Position:{data:[-.5,0,-.4,.5,-.5,-.4,.5,.5,-.4,.5,.4,-.2,-.5,.4,-.2,0,-.6,-.2]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0]}},i={u_ViewMatrix:C(m(),t(r.eye),t(r.target),t(r.upDirection)),u_ProjMatrix:d(m(),r.left,r.right,r.bottom,r.top,r.near,r.far)};const s=(o,n)=>{const a=u(o,l);c(o,n,a),_(n,i),p(o,a,o.TRIANGLES)};return b(()=>{const{gl:o,programInfo:n,clearGL:a}=f(h,y);s(o,n),e.on("change",()=>{a(),d(i.u_ProjMatrix,r.left,r.right,r.bottom,r.top,r.near,r.far),s(o,n)})}),g(()=>{e.dispose()}),(o,n)=>(B(),w("canvas"))}});export{k as default};
