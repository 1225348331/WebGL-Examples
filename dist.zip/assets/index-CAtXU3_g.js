import{i as d,c,s as m,a as _,d as p}from"./webgl-BK-JQzqJ.js";import{P as v}from"./tweakpane-DhSwS92u.js";import{d as B,o as S,b as w,P as A,K as F}from"./index-BtaXy4Tv.js";var g=`#version 300 es\r
precision highp float;

uniform float u_Resolution; 
uniform float u_Time; 
uniform float u_SnowflakeAmount; 
uniform float u_BlizardFactor; 
uniform float u_Speed; 

out vec4 outColor;\r
float rnd(float x) {\r
  return fract(sin(dot(vec2(x + 47.49f, 38.2467f / (x + 2.3f)), vec2(12.9898f, 78.233f))) * (43758.5453f));\r
}

float drawCircle(vec2 center, float radius, vec2 uv) {\r
  return 1.0f - smoothstep(0.0f, radius, length(uv - center));\r
}

void main() {\r
  vec2 uv = gl_FragCoord.xy / u_Resolution;\r
  outColor = vec4(0.808f, 0.89f, 0.918f, 1.0f);\r
  float j;\r
  for(float i = 0.0f; i < u_SnowflakeAmount; i++) {\r
    j = float(i);\r
    float speed = 0.3f + rnd(cos(j)) * (0.7f + 0.5f * cos(j / (float(u_SnowflakeAmount) * 0.25f)));\r
    vec2 center = vec2((0.25f - uv.y) * u_BlizardFactor + rnd(j) + 0.1f * cos(u_Speed * u_Time + sin(j)), mod(sin(j) - speed * (u_Speed * u_Time * 1.5f * (0.1f + u_BlizardFactor)), 1.0f));\r
    outColor += vec4(0.09f * drawCircle(center, 0.001f + speed * 0.012f, uv));\r
  }

}`,k=`#version 300 es

in vec4 a_Position;

void main() {\r
  gl_Position = a_Position;\r
}`;const b=B({__name:"index",setup(x){const o=new v({title:"天气-雪"});let n={SnowflakeAmount:100,BlizardFactor:.1,speed:1};return o.addBinding(n,"SnowflakeAmount",{label:"雪花数量",min:50,max:350}),o.addBinding(n,"BlizardFactor",{label:"暴风雪因子",min:0,max:1}),o.addBinding(n,"speed",{label:"下雪速度",min:1,max:10}),S(()=>{const{gl:e,programInfo:a,clearGL:i,width:u}=d(k,g);let s={a_Position:{numComponents:2,data:[-1,1,-1,-1,1,-1,1,1]}},r={u_Color:[0,1,0,1],u_Resolution:u,u_Time:0,u_Speed:n.speed,u_SnowflakeAmount:n.SnowflakeAmount,u_BlizardFactor:n.BlizardFactor};const l=()=>{const f=c(e,s);m(e,a,f),_(a,r),p(e,f,e.TRIANGLE_FAN)},t=()=>{r.u_Time+=1/200,i(),l(),requestAnimationFrame(t)};t(),o.on("change",()=>{r.u_Speed=n.speed,r.u_BlizardFactor=n.BlizardFactor,r.u_SnowflakeAmount=n.SnowflakeAmount})}),w(()=>{o.dispose()}),(e,a)=>(F(),A("canvas"))}});export{b as default};
