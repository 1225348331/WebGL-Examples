import{i as a,c as e,s as t,d as s}from"./webgl-BK-JQzqJ.js";import{d as i,o as f,P as l,K as c}from"./index-BtaXy4Tv.js";var _=`#version 300 es

in vec4 a_Position;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = a_Position;\r
  gl_PointSize = 80.0f;\r
  v_Color = a_Color;\r
}`,d=`#version 300 es\r
precision highp float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  float distance = distance(gl_PointCoord, vec2(0.5f, 0.5f));\r
  float alpha = smoothstep(0.48f, 0.52f, distance); 
  outColor = mix(v_Color, vec4(0.0f, 0.0f, 0.0f, 0.0f), alpha);\r
}`;const C=i({__name:"index",setup(m){return f(()=>{const{gl:o,programInfo:n}=a(_,d),r=e(o,{a_Position:{numComponents:2,data:[0,0,-.5,0,.5,0]},a_Color:{numComponents:3,data:[0,1,0,0,1,0,0,1,0]}});t(o,n,r),s(o,r,o.POINTS)}),(o,n)=>(c(),l("canvas"))}});export{C as default};
