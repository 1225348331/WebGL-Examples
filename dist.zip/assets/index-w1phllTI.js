import{i as f,c as l,s as _,a as c,d as p}from"./webgl-BK-JQzqJ.js";import{P as b}from"./tweakpane-DhSwS92u.js";import{d as h,o as v,b as g,P as C,K as x}from"./index-BtaXy4Tv.js";var w=`#version 300 es\r
precision highp float;

uniform float u_Resolution; 
uniform float u_Time; 
uniform float u_Speed; 
uniform float u_Number; 
uniform vec4 u_Color; 
uniform float u_Width; 

out vec4 outColor;

void main() {\r
  float dist = distance(vec2(gl_FragCoord.x / u_Resolution, gl_FragCoord.y / u_Resolution), vec2(0.5f, 0.5f));\r
  float ratio = mod(u_Time * u_Speed - dist * u_Resolution, u_Resolution / u_Number);\r
  if(ratio > 0.0f && ratio <= u_Width * u_Resolution / u_Number) {\r
    float opacity = 0.5f - dist;\r
    outColor = vec4(u_Color.xyz, opacity * 2.0f);\r
  } else {\r
    outColor = vec4(0.0f, 0.0f, 0.0f, 0.0f);\r
  }\r
}`,B=`#version 300 es

in vec4 a_Position;

void main() {\r
  gl_Position = a_Position;\r
}`;const A=h({__name:"index",setup(R){const o=new b({title:"平面扩散波"});let n={speed:20,number:6,width:.3};return o.addBinding(n,"speed",{label:"扩散速度",min:5,max:50}),o.addBinding(n,"number",{label:"波纹数量",min:2,max:20}),o.addBinding(n,"width",{label:"波纹宽度",min:.1,max:1}),v(()=>{const{gl:e,programInfo:t,clearGL:u,width:s}=f(B,w);let d={a_Position:{numComponents:2,data:[-1,1,-1,-1,1,-1,1,1]}},r={u_Color:[0,1,0,1],u_Resolution:s,u_Time:0,u_Speed:n.speed,u_Number:n.number,u_Width:n.width};const m=()=>{const a=l(e,d);_(e,t,a),c(t,r),p(e,a,e.TRIANGLE_FAN)},i=()=>{r.u_Time+=1/50,u(),m(),requestAnimationFrame(i)};i(),o.on("change",()=>{r.u_Speed=n.speed,r.u_Number=n.number,r.u_Width=n.width})}),g(()=>{o.dispose()}),(e,t)=>(x(),C("canvas"))}});export{A as default};
