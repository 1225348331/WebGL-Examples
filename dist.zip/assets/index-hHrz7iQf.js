import{i as d,c as M,s as v,a as c,d as f}from"./webgl-BK-JQzqJ.js";import{P as x}from"./tweakpane-DhSwS92u.js";import{d as p,o as P,b as g,P as C,K as h}from"./index-BtaXy4Tv.js";import{c as e,l as A,p as b,t as u,a as L,r as N,s as B}from"./mat4-BT8WumiK.js";import{f as a}from"./vec3-CN1kTKF3.js";var w=`#version 300 es

in vec4 a_Position;\r
in vec4 a_Normal;\r
uniform vec4 u_Color;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r

out vec4 v_Color;\r
out vec4 v_Normal;\r
out vec4 v_Position;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Position = u_ModelMatrix * a_Position;\r
  mat4 nomalMatrix = transpose(inverse(u_ModelMatrix));\r
  v_Normal = normalize(nomalMatrix * a_Normal);\r
  v_Color = u_Color;\r
}`,j=`#version 300 es\r
precision highp float;\r
in vec4 v_Color;\r
in vec4 v_Normal;\r
in vec4 v_Position;\r
uniform vec4 u_LightColor;\r
uniform vec4 u_LightPosition;\r
uniform vec4 u_AmbientColor;

out vec4 outColor;

void main() {\r
  vec4 diffuse = u_LightColor * v_Color * max(dot(normalize(u_LightPosition - v_Position), normalize(v_Normal)), 0.0f);\r
  vec4 ambient = u_AmbientColor * v_Color;\r
  outColor = vec4(vec3(diffuse + ambient), v_Color.a);\r
}`;const y=p({__name:"index",setup(I){let m={a_Position:{numComponents:3,data:[1.5,10,1.5,-1.5,10,1.5,-1.5,0,1.5,1.5,0,1.5,1.5,10,1.5,1.5,0,1.5,1.5,0,-1.5,1.5,10,-1.5,1.5,10,1.5,1.5,10,-1.5,-1.5,10,-1.5,-1.5,10,1.5,-1.5,10,1.5,-1.5,10,-1.5,-1.5,0,-1.5,-1.5,0,1.5,-1.5,0,-1.5,1.5,0,-1.5,1.5,0,1.5,-1.5,0,1.5,1.5,0,-1.5,-1.5,0,-1.5,-1.5,10,-1.5,1.5,10,-1.5]},a_Normal:{numComponents:3,data:[0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},o={u_Color:[1,0,0,1],u_ModelMatrix:e(),u_ViewMatrix:A(e(),a(20,20,30),a(0,0,0),a(0,1,0)),u_ProjMatrix:b(e(),50*Math.PI/180,1,2,100),u_NormalMatrix:e(),u_LightColor:[1,0,0,1],u_LightPosition:[20,10,100,1],u_AmbientColor:[.2,.2,.2,1]},i=new x,t={g_arm1Angle:-90,g_joint1Angle:0};i.addBinding(t,"g_arm1Angle",{label:"关节1角度",min:-180,max:180}),i.addBinding(t,"g_joint1Angle",{label:"关节2角度",min:-90,max:90});const l=(r,n)=>{const _=M(r,m);v(r,n,_),c(n,o),f(r,_,r.TRIANGLES)},s=(r,n)=>{o.u_ModelMatrix=e(),u(o.u_ModelMatrix,o.u_ModelMatrix,a(0,-12,0)),L(o.u_ModelMatrix,o.u_ModelMatrix,t.g_arm1Angle*Math.PI/180),l(r,n),u(o.u_ModelMatrix,o.u_ModelMatrix,a(0,10,0)),N(o.u_ModelMatrix,o.u_ModelMatrix,t.g_joint1Angle*Math.PI/180),B(o.u_ModelMatrix,o.u_ModelMatrix,a(1.3,1,1.3)),l(r,n)};return P(()=>{const{gl:r,programInfo:n,clearGL:_}=d(w,j);s(r,n),i.on("change",()=>{_(),s(r,n)})}),g(()=>{i.dispose()}),(r,n)=>(h(),C("canvas"))}});export{y as default};
