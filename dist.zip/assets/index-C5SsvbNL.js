import{i as f,e as _,c as d,s as v,a as x,d as T}from"./webgl-BK-JQzqJ.js";import{P as C}from"./tweakpane-DhSwS92u.js";import{g as P,a as I,b as r}from"./utils-DhsMP5cn.js";import{d as S,o as A,b as B,P as R,K as b}from"./index-BtaXy4Tv.js";var E=`#version 300 es

in vec4 a_Position;\r
out vec2 v_Position;

void main() {\r
  gl_Position = a_Position;\r
  v_Position = (a_Position.xy + vec2(1.0f, 1.0f)) / 2.0f;\r
}`,g=`#version 300 es\r
precision mediump float;

in vec2 v_Position; 
uniform sampler2D u_Texture; 
uniform sampler2D u_ColorTexture; 
uniform bool u_IsStep; 
struct clampColor {\r
  float stop;\r
  vec4 color;\r
};

uniform clampColor clampColors[10];\r
out vec4 outColor;

void main() {\r
  float val = texture(u_Texture, v_Position).r;\r
  if(u_IsStep) {\r
    for(int i = 1; i < 10; i++) {\r
      if(val >= clampColors[i - 1].stop && val < clampColors[i].stop) {\r
        outColor = clampColors[i].color;\r
        break;\r
      }\r
    }\r
  } else {\r
    outColor = texture(u_ColorTexture, vec2(val, 0.5f));\r
  }\r
}`;const U=S({__name:"index",setup(h){let i=P(),l=i.map(o=>({text:o.replaceAll("/data/",""),value:o}));const n=new C({title:"绘制格点数据"});let e={imgSrc:l[0].value,isStep:!0,time:0};n.addBlade({view:"list",label:"温度图",options:l,value:e.imgSrc}),n.addBinding(e,"isStep",{label:"是否分级渲染"});const u=(o,t)=>{_(o,{dataTexture:{src:e.imgSrc,min:o.LINEAR,mag:o.LINEAR},colorTexture:{src:I(),min:o.LINEAR,mag:o.LINEAR,width:256,height:1}},(a,s)=>{let m={a_Position:{numComponents:2,data:[-1,1,-1,-1,1,1,1,-1]}},p={u_Texture:s.dataTexture,u_Texture2:s.dataTexture2,u_ColorTexture:s.colorTexture,u_IsStep:e.isStep,u_Time:e.time,clampColors:[{stop:0,color:r(0)},{stop:.1,color:r(.1)},{stop:.2,color:r(.2)},{stop:.3,color:r(.3)},{stop:.4,color:r(.4)},{stop:.5,color:r(.5)},{stop:.6,color:r(.6)},{stop:.7,color:r(.7)},{stop:.8,color:r(.8)},{stop:1,color:r(1)}]};const c=d(o,m);v(o,t,c),x(t,p),o.clear(o.COLOR_BUFFER_BIT|o.DEPTH_BUFFER_BIT),T(o,c,o.TRIANGLE_STRIP)})};return A(()=>{const{gl:o,programInfo:t}=f(E,g);u(o,t),n.on("change",a=>{i.includes(a.value)&&(e.imgSrc=a.value),u(o,t)})}),B(()=>{n.dispose()}),(o,t)=>(b(),R("canvas"))}});export{U as default};
