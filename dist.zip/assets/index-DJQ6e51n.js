import{i as e,c as a,s as t,d as s}from"./webgl-BK-JQzqJ.js";import{d as i,o as f,P as _,K as c}from"./index-BtaXy4Tv.js";var m=`#version 300 es

in vec4 a_Position;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = a_Position;\r
  v_Color = a_Color;\r
}`,u=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`;const C=i({__name:"index",setup(l){return f(()=>{const{gl:o,programInfo:n}=e(m,u),r=a(o,{a_Position:{numComponents:2,data:[-.5,-.5,.5,-.5,0,.5]},a_Color:{numComponents:3,data:[1,0,0,0,1,0,0,0,1]}});t(o,n,r),s(o,r,o.TRIANGLES)}),(o,n)=>(c(),_("canvas"))}});export{C as default};
