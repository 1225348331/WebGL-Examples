import{i as r,c as a,s as t,d as i}from"./webgl-BK-JQzqJ.js";import{d as s,o as f,P as c,K as _}from"./index-BtaXy4Tv.js";var m=`#version 300 es

in vec4 a_Position;\r
in float a_PointSize;\r
void main() {\r
  gl_Position = a_Position;\r
  gl_PointSize = a_PointSize;\r
}`,u=`#version 300 es\r
precision highp float;

out vec4 outColor;

void main() {\r
  outColor = vec4(1.0, 0.0, 0.2, 1.0);\r
}`;const P=s({__name:"index",setup(d){return f(()=>{const{gl:n,programInfo:o}=r(m,u),e=a(n,{a_Position:{numComponents:2,data:[0,0]},a_PointSize:{numComponents:1,data:[20]}});t(n,o,e),i(n,e,n.POINTS)}),(n,o)=>(_(),c("canvas"))}});export{P as default};
