import{i as c,c as l,s as u,a as _,d as p}from"./webgl-BK-JQzqJ.js";import{P as v}from"./tweakpane-DhSwS92u.js";import{d as x,o as P,b as C,P as M,K as w}from"./index-BtaXy4Tv.js";import{l as B,c as m,p as f}from"./mat4-BT8WumiK.js";import{f as b}from"./vec3-CN1kTKF3.js";var g=`#version 300 es

in vec4 a_Position;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
in vec4 a_Color;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * a_Position;\r
  v_Color = a_Color;\r
}`,y=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`;const k=x({__name:"index",setup(h){const t=a=>b(a.x,a.y,a.z),e=new v;let r={eye:{x:0,y:0,z:0},target:{x:0,y:0,z:-1},upDirection:{x:0,y:1,z:0},near:1,far:6,fov:45,aspect:1};e.addBinding(r,"near",{view:"slider",min:0,max:3,label:"近裁剪面"}),e.addBinding(r,"far",{view:"slider",min:3,max:6,label:"远裁剪面"}),e.addBinding(r,"fov",{view:"slider",min:0,max:180,label:"夹角"}),e.addBinding(r,"aspect",{min:1,max:1,label:"宽高比"});let d={a_Position:{data:[-.5,0,-4,.5,-.5,-4,.5,.5,-4,.5,.4,-2,-.5,.4,-2,0,-.6,-2]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0]}},i={u_ViewMatrix:B(m(),t(r.eye),t(r.target),t(r.upDirection)),u_ProjMatrix:f(m(),r.fov*Math.PI/180,r.aspect,r.near,r.far)};const s=(a,n)=>{const o=l(a,d);u(a,n,o),_(n,i),p(a,o,a.TRIANGLES)};return P(()=>{const{gl:a,programInfo:n,clearGL:o}=c(g,y);s(a,n),e.on("change",()=>{o(),f(i.u_ProjMatrix,r.fov*Math.PI/180,r.aspect,r.near,r.far),s(a,n)})}),C(()=>{e.dispose()}),(a,n)=>(w(),M("canvas"))}});export{k as default};
