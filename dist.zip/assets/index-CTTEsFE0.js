import{i as s,c as _,s as m,a as u,d as l}from"./webgl-BK-JQzqJ.js";import{d as v,o as f,P as c,K as d}from"./index-BtaXy4Tv.js";import{c as r,l as C,p}from"./mat4-BT8WumiK.js";import{f as i}from"./vec3-CN1kTKF3.js";var M=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
in vec4 v_Position;\r
in vec4 v_Normal;\r
out vec4 outColor;\r
uniform vec4 u_LightPosition; 
uniform vec4 u_LightColor; 
uniform vec4 u_AmbientColor; 

void main() {\r
  vec4 diffuse = v_Color * u_LightColor * max(dot(normalize(u_LightPosition - v_Position), normalize(v_Normal)), 0.0f);\r
  vec4 ambient = u_AmbientColor * v_Color;\r
  outColor = vec4(vec3(diffuse + ambient), v_Color.a);\r
}`,P=`#version 300 es

uniform mat4 u_ModelMatrix; 
uniform mat4 u_ViewMatrix; 
uniform mat4 u_ProjMatrix; 
in vec4 a_Position; 
in vec4 a_Normal; 
in vec4 a_Color; 

out vec4 v_Position;\r
out vec4 v_Normal;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Position = u_ModelMatrix * a_Position;\r
  v_Normal = normalize(transpose(inverse(u_ModelMatrix)) * a_Normal);\r
  v_Color = a_Color;\r
}`;const L=v({__name:"index",setup(x){const a={a_Position:{numComponents:3,data:[2,2,2,-2,2,2,-2,-2,2,2,-2,2,2,2,2,2,-2,2,2,-2,-2,2,2,-2,2,2,2,2,2,-2,-2,2,-2,-2,2,2,-2,2,2,-2,2,-2,-2,-2,-2,-2,-2,2,-2,-2,-2,2,-2,-2,2,-2,2,-2,-2,2,2,-2,-2,-2,-2,-2,-2,2,-2,2,2,-2]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0]},a_Normal:{numComponents:3,data:[0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},t={u_ModelMatrix:r(),u_ViewMatrix:C(r(),i(6,6,14),i(0,0,0),i(0,1,0)),u_ProjMatrix:p(r(),40*Math.PI/180,1,2,100),u_LightColor:[1,1,1,1],u_LightPosition:[2.3,4,3.5,1],u_AmbientColor:[.2,.2,.2,1]};return f(()=>{const{gl:o,programInfo:n}=s(P,M),e=_(o,a);m(o,n,e),u(n,t),l(o,e,o.TRIANGLES)}),(o,n)=>(d(),c("canvas"))}});export{L as default};
