import{i as P,c as A,s as C,a as h,d as p}from"./webgl-BK-JQzqJ.js";import{P as j}from"./tweakpane-DhSwS92u.js";import{d as b,o as B,P as L,K as N}from"./index-BtaXy4Tv.js";import{c as M,l as w,p as I,t as i,a as s,r as V,d as m,e as x,s as k}from"./mat4-BT8WumiK.js";import{f as e}from"./vec3-CN1kTKF3.js";var z=`#version 300 es

in vec4 a_Position;\r
in vec4 a_Normal;\r
uniform vec4 u_Color;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r

out vec4 v_Color;\r
out vec4 v_Normal;\r
out vec4 v_Position;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Position = u_ModelMatrix * a_Position;\r
  mat4 nomalMatrix = transpose(inverse(u_ModelMatrix));\r
  v_Normal = normalize(nomalMatrix * a_Normal);\r
  v_Color = u_Color;\r
}`,G=`#version 300 es\r
precision highp float;\r
in vec4 v_Color;\r
in vec4 v_Normal;\r
in vec4 v_Position;\r
uniform vec4 u_LightColor;\r
uniform vec4 u_LightPosition;\r
uniform vec4 u_AmbientColor;

out vec4 outColor;

void main() {\r
  vec4 diffuse = u_LightColor * v_Color * max(dot(normalize(u_LightPosition - v_Position), normalize(v_Normal)), 0.0f);\r
  vec4 ambient = u_AmbientColor * v_Color;\r
  outColor = vec4(vec3(diffuse + ambient), v_Color.a);\r
}`;const T=b({__name:"index",setup(S){let c={a_Position:{numComponents:3,data:[.5,1,.5,-.5,1,.5,-.5,0,.5,.5,0,.5,.5,1,.5,.5,0,.5,.5,0,-.5,.5,1,-.5,.5,1,.5,.5,1,-.5,-.5,1,-.5,-.5,1,.5,-.5,1,.5,-.5,1,-.5,-.5,0,-.5,-.5,0,.5,-.5,0,-.5,.5,0,-.5,.5,0,.5,-.5,0,.5,.5,0,-.5,-.5,0,-.5,-.5,1,-.5,.5,1,-.5]},a_Normal:{numComponents:3,data:[0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},o={u_Color:[1,.4,0,1],u_ModelMatrix:M(),u_ViewMatrix:w(M(),e(20,10,30),e(0,0,0),e(0,1,0)),u_ProjMatrix:I(M(),50*Math.PI/180,1,2,100),u_NormalMatrix:M(),u_LightColor:[1,1,1,.5],u_LightPosition:[20,10,100,1],u_AmbientColor:[.2,.2,.2,1]},l=new j,t={g_arm1Angle:90,g_joint1Angle:45,g_joint2Angle:0,g_joint3Angle:0};l.addBinding(t,"g_arm1Angle",{label:"关节1角度",min:-180,max:180}),l.addBinding(t,"g_joint1Angle",{label:"关节2角度",min:-90,max:90}),l.addBinding(t,"g_joint2Angle",{label:"关节3角度",min:-90,max:90}),l.addBinding(t,"g_joint3Angle",{label:"关节4角度",min:-90,max:90});const n=(r,a,_,v,f)=>{let g=m(o.u_ModelMatrix);k(o.u_ModelMatrix,o.u_ModelMatrix,e(_,v,f));const d=A(r,c);C(r,a,d),h(a,o),p(r,d,r.TRIANGLES),o.u_ModelMatrix=g},u=(r,a)=>{o.u_ModelMatrix=M(),i(o.u_ModelMatrix,o.u_ModelMatrix,e(0,-12,0)),n(r,a,10,2,10),i(o.u_ModelMatrix,o.u_ModelMatrix,e(0,2,0)),s(o.u_ModelMatrix,o.u_ModelMatrix,t.g_arm1Angle*Math.PI/180),n(r,a,3,10,3),i(o.u_ModelMatrix,o.u_ModelMatrix,e(0,10,0)),V(o.u_ModelMatrix,o.u_ModelMatrix,t.g_joint1Angle*Math.PI/180),n(r,a,4,10,4),i(o.u_ModelMatrix,o.u_ModelMatrix,e(0,10,0)),s(o.u_ModelMatrix,o.u_ModelMatrix,t.g_joint2Angle*Math.PI/180),n(r,a,2,2,6),i(o.u_ModelMatrix,o.u_ModelMatrix,e(0,2,0));let _=m(o.u_ModelMatrix);i(o.u_ModelMatrix,o.u_ModelMatrix,e(0,0,2)),x(o.u_ModelMatrix,o.u_ModelMatrix,t.g_joint3Angle*Math.PI/180),n(r,a,1,2,1),o.u_ModelMatrix=_,i(o.u_ModelMatrix,o.u_ModelMatrix,e(0,0,-2)),x(o.u_ModelMatrix,o.u_ModelMatrix,-(t.g_joint3Angle*Math.PI)/180),n(r,a,1,2,1)};return B(()=>{const{gl:r,programInfo:a,clearGL:_}=P(z,G);u(r,a),l.on("change",()=>{_(),u(r,a)})}),(r,a)=>(N(),L("canvas"))}});export{T as default};
