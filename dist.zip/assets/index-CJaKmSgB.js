import{i as v,c as f,s as d,a as C,d as P}from"./webgl-BK-JQzqJ.js";import{P as p}from"./tweakpane-DhSwS92u.js";import{d as x,o as M,P as g,K as h}from"./index-BtaXy4Tv.js";import{A as c,s as A,c as _,l as b,p as L}from"./mat4-BT8WumiK.js";import{f as l}from"./vec3-CN1kTKF3.js";function w(){var o=new c(4);return c!=Float32Array&&(o[0]=0,o[1]=0,o[2]=0,o[3]=0),o}function m(o,r,e,u){var i=new c(4);return i[0]=o,i[1]=r,i[2]=e,i[3]=u,i}(function(){var o=w();return function(r,e,u,i,s,t){var n,a;for(e||(e=4),u||(u=0),i?a=Math.min(i*e+u,r.length):a=r.length,n=u;n<a;n+=e)o[0]=r[n],o[1]=r[n+1],o[2]=r[n+2],o[3]=r[n+3],s(o,o,t),r[n]=o[0],r[n+1]=o[1],r[n+2]=o[2],r[n+3]=o[3];return r}})();var y=`#version 300 es

in vec4 a_Position;\r
in vec4 a_Color;\r
in vec4 a_Normal;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
out vec4 v_Position;\r
out vec4 v_Normal;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Position = u_ModelMatrix * a_Position;\r
  v_Normal = transpose(inverse(u_ModelMatrix)) * a_Normal;\r
  v_Color = a_Color;\r
}`,N=`#version 300 es\r
precision mediump float;

in vec4 v_Position;\r
in vec4 v_Normal;\r
in vec4 v_Color;

uniform vec4 u_LightColor; 
uniform vec4 u_LightPosition; 
uniform vec4 u_AmbientColor; 
uniform vec4 u_EyePosition; 
uniform vec2 u_Dist; 
uniform vec4 u_FogColor; 
out vec4 outColor;

void main() {\r
  
  vec4 diffuse = v_Color * u_LightColor * max(dot(normalize(u_LightPosition - v_Position), normalize(v_Normal)), 0.0f);\r
  
  vec4 ambient = v_Color * u_AmbientColor;\r
  
  float fogFactor = clamp((u_Dist.y - distance(v_Position, u_EyePosition)) / (u_Dist.y - u_Dist.x), 0.0f, 1.0f);\r
  
  outColor = vec4(vec3(diffuse + ambient), v_Color.a);\r
  
  outColor = mix(u_FogColor, v_Color, fogFactor);\r
}`;const V=x({__name:"index",setup(o){const r=new p({title:"雾化距离控制"});let e={dist:80};r.addBinding(e,"dist",{min:55,max:110,label:"能见距离"});let u={a_Position:{numComponents:3,data:[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,-1,1,-1,-1,1,1,-1,1,1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1]},a_Color:{numComponents:3,data:[.4,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,.4,.4,1,1,.4,1,1,.4,1,1,.4,1,1,.4,1,1,1,1,1,1,1,1,1,1,1,1,.4,1,1,.4,1,1,.4,1,1,.4,1,1]},a_Normal:{numComponents:3,data:[0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},i={u_ModelMatrix:A(_(),_(),l(10,10,10)),u_ViewMatrix:b(_(),l(25,65,35),l(0,2,0),l(0,1,0)),u_ProjMatrix:L(_(),30*Math.PI/180,1,1,1e3),u_LightColor:m(1,1,1,1),u_LightPosition:m(2.3,4,3.5,1),u_AmbientColor:m(.2,.2,.2,1),u_FogColor:m(.137,.231,.423,1),u_Dist:[55,80],u_EyePosition:[25,65,35,1]};const s=(t,n)=>{const a=f(t,u);d(t,n,a),C(n,i),P(t,a,t.TRIANGLES)};return M(()=>{const{gl:t,programInfo:n,clearGL:a}=v(y,N);t.clearColor(.137,.231,.423,1),a(),s(t,n),r.on("change",()=>{i.u_Dist[1]=e.dist,a(),s(t,n)})}),(t,n)=>(h(),g("canvas"))}});export{V as default};
