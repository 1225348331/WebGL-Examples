import{i as v,b as p,c as x,s as C,a as F,d as P}from"./webgl-BK-JQzqJ.js";import{i as B}from"./landScape-WBMzbjzh.js";import{d as M,o as k,P as T,K as I}from"./index-BtaXy4Tv.js";import{c as _,l as E,p as b}from"./mat4-BT8WumiK.js";import{f}from"./vec3-CN1kTKF3.js";var w=`#version 300 es

in vec4 a_Position;

in float a_Face;\r
uniform mat4 u_ModelMatrix;\r
uniform mat4 u_ViewMatrix;\r
uniform mat4 u_ProjMatrix;\r
uniform int u_PickedFace;\r
out vec4 v_Color;\r

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  vec4 a_Color = vec4(1.0f, 0.0f, 1.0f, 1.0f);\r
  vec4 pickColor = vec4(0.0f, 0.0f, 0.0f, 1.0f);\r
  int face = int(a_Face);\r
  vec3 color = (face == u_PickedFace) ? pickColor.rgb : a_Color.rgb;\r
  if(u_PickedFace == 0) {\r
    v_Color = vec4(color, a_Face / 255.0f);\r
  } else {\r
    v_Color = vec4(color, 1.0f);\r
  }\r
}`,A=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
out vec4 outColor;

void main() {\r
  outColor = v_Color;\r
}`;const G=M({__name:"index",setup(R){let l={a_Position:{numComponents:3,data:[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,1,-1,-1,1,-1,-1,1,1,-1,1,1,-1,1,-1,-1,-1,-1,-1,-1,1,-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1,1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1]},a_TexCoord:{numComponents:2,data:[1,1,0,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,1,1,0,1,0,0,1,1,0,1,0,0,1,0,0,0,1,0,1,1,0,1,0,0,1,0,1,1,0,1]},a_Face:{numComponents:1,data:[1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,6,6,6,6]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},t={u_ModelMatrix:_(),u_ViewMatrix:E(_(),f(3,3,7),f(0,0,0),f(0,1,0)),u_ProjMatrix:b(_(),50*Math.PI/180,1,2,100),u_Texture:null,u_PickedFace:-1};const s=(e,r)=>{const a=x(e,l);C(e,r,a),F(r,t),e.clear(e.COLOR_BUFFER_BIT|e.DEPTH_BUFFER_BIT|e.STENCIL_BUFFER_BIT),P(e,a,e.TRIANGLES)};return k(()=>{const{gl:e,programInfo:r,canvas:a}=v(w,A);p(e,{src:B,flipY:1},(i,n,c)=>{t.u_Texture=n,s(e,r)}),a.onmousedown=i=>{let n=i.clientX,c=i.clientY,o=i.target.getBoundingClientRect();if(o.left<=n&&n<o.right&&o.top<=c&&c<o.bottom){let m=n-o.left,d=o.bottom-c;t.u_PickedFace=0,s(e,r);let u=new Uint8Array(4);e.readPixels(m,d,1,1,e.RGBA,e.UNSIGNED_BYTE,u),t.u_PickedFace=u[3],s(e,r)}}}),(e,r)=>(I(),T("canvas"))}});export{G as default};
