import{i as m,c as u,s as l,a as c,d as v}from"./webgl-BK-JQzqJ.js";import{d as f,o as d,P as M,K as x}from"./index-BtaXy4Tv.js";import{c as i,l as C,p,a as P,b as N,i as h}from"./mat4-BT8WumiK.js";import{f as t}from"./vec3-CN1kTKF3.js";var b=`#version 300 es\r
precision mediump float;

in vec4 v_Color;\r
in vec4 v_Position;\r
in vec4 v_Normal;\r
out vec4 outColor;\r
uniform vec4 u_LightPosition; 
uniform vec4 u_LightColor; 
uniform vec4 u_AmbientColor; 

void main() {\r
  
  vec4 diffuse = v_Color * u_LightColor * max(dot(normalize(v_Normal), normalize(u_LightPosition - v_Position)), 0.0f);\r
  
  vec4 ambient = u_AmbientColor * v_Color;\r
  outColor = vec4(vec3(diffuse + ambient), v_Color.a);\r
}`,A=`#version 300 es

uniform mat4 u_ModelMatrix; 
uniform mat4 u_ViewMatrix; 
uniform mat4 u_ProjMatrix; 
uniform mat4 u_NormalMatrix; 
in vec4 a_Position; 
in vec4 a_Normal; 
in vec4 a_Color; 

out vec4 v_Position;\r
out vec4 v_Normal;\r
out vec4 v_Color;

void main() {\r
  gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\r
  v_Position = u_ModelMatrix * a_Position;\r
  v_Normal = normalize(u_NormalMatrix * a_Normal);\r
  v_Color = a_Color;\r
}`;const k=f({__name:"index",setup(L){const s={a_Position:{numComponents:3,data:[2,2,2,-2,2,2,-2,-2,2,2,-2,2,2,2,2,2,-2,2,2,-2,-2,2,2,-2,2,2,2,2,2,-2,-2,2,-2,-2,2,2,-2,2,2,-2,2,-2,-2,-2,-2,-2,-2,2,-2,-2,-2,2,-2,-2,2,-2,2,-2,-2,2,2,-2,-2,-2,-2,-2,-2,2,-2,2,2,-2]},a_Color:{numComponents:3,data:[1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0]},a_Normal:{numComponents:3,data:[0,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0,-1,0,0,-1,0,0,-1]},indices:[0,1,2,0,2,3,4,5,6,4,6,7,8,9,10,8,10,11,12,13,14,12,14,15,16,17,18,16,18,19,20,21,22,20,22,23]},o={u_ModelMatrix:i(),u_ViewMatrix:C(i(),t(6,6,14),t(0,0,0),t(0,1,0)),u_ProjMatrix:p(i(),45*Math.PI/180,1,2,100),u_LightColor:[1,1,1,1],u_LightPosition:[2.3,4,3.5,1],u_AmbientColor:[.2,.2,.2,1],u_NormalMatrix:i()},_=(r,n)=>{const a=u(r,s);l(r,n,a),c(n,o),v(r,a,r.TRIANGLES)};return d(()=>{const{gl:r,programInfo:n,clearGL:a}=m(A,b),e=()=>{P(o.u_ModelMatrix,o.u_ModelMatrix,Math.PI/3600),N(o.u_NormalMatrix,o.u_ModelMatrix),h(o.u_NormalMatrix,o.u_NormalMatrix),a(),_(r,n),requestAnimationFrame(e)};e()}),(r,n)=>(x(),M("canvas"))}});export{k as default};
