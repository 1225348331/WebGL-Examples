import{i as l,c as _,s as m,d as p}from"./webgl-BK-JQzqJ.js";import{d as v,o as h,P as B,K as P}from"./index-BtaXy4Tv.js";var g=`#version 300 es

in vec4 a_Position;

void main() {\r
  gl_Position = a_Position;\r
  gl_PointSize = 20.0f;\r
}`,I=`#version 300 es\r
precision mediump float;

out vec4 outColor;

void main() {\r
  outColor = vec4(1.0f, 0.0f, 1.0f, 1.0f);\r
}`;const x=v({__name:"index",setup(C){let s=[];const d=(e,o,r)=>{const n=_(e,r);m(e,o,n),p(e,n,e.POINTS)};return h(()=>{var r;const{gl:e,programInfo:o}=l(g,I);(r=document.querySelector("canvas"))==null||r.addEventListener("click",n=>{var c;let a=n.clientX,i=n.clientY;const t=(c=n.target)==null?void 0:c.getBoundingClientRect();a=(a-t.left-t.width/2)/(t.width/2),i=(t.height/2-(i-t.top))/(t.height/2),s.push([a,i]),e.clear(e.COLOR_BUFFER_BIT|e.DEPTH_BUFFER_BIT),s.forEach(f=>{let u={a_Position:{numComponents:2,data:[f[0],f[1]]}};d(e,o,u)})})}),(e,o)=>(P(),B("canvas"))}});export{x as default};
